# RAYNF.github.io-UasDaskom

merupkan sebuah tampilan Wesbsite yang saya gunakan untuk Uas mata kuliah doskom semester 1 dengan bootstrap

# Link Website

https://raynf.github.io/RAYNF.github.io-UasDaskom/index.html

![design](beranda.png)
